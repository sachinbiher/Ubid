<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Created</title>

    <!--bootstrap css -->
    <link rel="stylesheet" type="text/css" href="{{url('app-assets/mail-assets/css/bootstrap.min.css')}}">
    <!--fontawesome icons-->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <!--Custom css-->
    <style>
        * {
    box-sizing: border-box;
    padding: 0;
    margin: 0;
    font-family: Century Gothic;
    color: #000;
}

@font-face {
    font-family: Century Gothic;
    src: url('app-assets/mail-assets/fonts/GOTHIC.TTF');
}

ul {
    padding: 0;
    margin: 0;
}

li {
    list-style: none;
}

a:focus,
a:hover {
    text-decoration: none;
}

a:focus {
    outline: 0;
}

hr {
    max-width: 550px;
    height: 2px;
    color: #b35b25;
    margin: .5rem 0;
    opacity: 1;
}

.content {
    width: 100%;
    max-width: 550px;
    margin: 0 auto;
    text-align: center;
}

.approve {
    color: #b35b25;
    margin: 10px 0;
}

.login-button {
    color: #000;
    font-size: 18px;
    cursor: pointer;
    background: #2EEAB7;
    padding: 3px 50px;
    border: 1px solid #adb5bd;
    border-radius: 30px;
    outline: none;
}

.social-medialinks {
    display: flex;
}

.social-medialinks a {
    display: flex;
    background: #fff;
    height: 35px;
    width: 35px;
    margin-right: 5px;
    border-radius: 30px;
    justify-content: center;
    align-items: center;
    text-decoration: none;
    border: 1px solid #adb5bd;
    transition: transform 0.5s;
}

.social-medialinks a i {
    font-size: 18px;
    color: #777;
    transition: transform 0.5s;
}

.social-medialinks .social-button.instagram:hover,
.social-medialinks .social-button.instagram:focus {
    color: #fff;
    background: #c13584;
    border-color: #c13584;
}

.social-medialinks .social-button.facebook:hover,
.social-medialinks .social-button.facebook:focus {
    color: #fff;
    background: #3b5b99;
    border-color: #3b5998;
}

.social-medialinks .social-button.twitter:hover,
.social-medialinks .social-button.twitter:focus {
    color: #fff;
    background: #00aced;
    border-color: #00aced;
}

.social-medialinks a i:hover {
    color: #fff;
}

.contact-details li a {
    text-decoration: none;
    color: #000;
}

.visit-sitelink {
    display: inline-block;
    color: #000;
    font-size: 15px;
    cursor: pointer;
    background: #e78e57cc;
    padding: 5px 5px;
    margin: 10px;
    border: 1px solid #adb5bd;
    border-radius: 30px;
    outline: none;
    text-decoration: underline;
    margin-bottom: 0;
}

.visit-sitelink:hover {
    color: #000;
    text-decoration: underline;
}

.arrow::before {
    content: '->';
    color: #000;
}

/* Responsive */
@media (max-width:600px) {
    .content .description {
        font-size: 14px;
    }
}
    </style>
</head>

<body>
    <div class="container" style="max-width: 550px;">
        <div class="d-flex justify-content-center logo">
            <nav class="navbar navbar-light">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#">
                    <img src="{{url('app-assets/mail-assets/logo/UBID-Logo-1X@2x.png')}}" alt="" width="50" height="" class="d-inline-block">
                        <img src="{{url('app-assets/mail-assets/logo/UBID Text-1x@2x.png')}}" alt="" width="100" height=""
                            class="d-inline-block">
                    </a>
                </div>
            </nav>
        </div>
        <hr>
    </div>

    <div class="container">
        <div class="content">
            <img src="{{url('app-assets/mail-assets/images/undraw_happy_announcement_ac67.png')}}" alt="" width="300">
            <h3>Thanks!</h3>
            <p class="description mt-3">Thanks for your time, It was greating working with you and I'm glad we could complete your project. <br>If you have a few mintues today, we would love to get
            your feedback on your experience.<br>Follow the link to access the <a href= "{{route('clienttestimonial',['vendor_id'=>$vendorid])}}" >feedback form</a> and leave your testimonial.<br>In meantime, please reach me out if you have any questions</p>

            <div class="">
                <hr>
            </div>
            <!-- Contact Details -->
            <div class="row">
                <div class="col-5 text-start">
                    <p>Follow us on</p>
                    <div class="">
                        <a href="https://www.instagram.com/ubidindia/"><img src="http://13.126.160.234/ubid/app-assets/mail-assets/images/instagram.png" width="25px" alt="" srcset=""></a>
                        <a href="https://www.facebook.com/ubidindia/"><img src="http://13.126.160.234/ubid/app-assets/mail-assets/images/facebook.png" width="25px" alt="" srcset=""></a>
                        <a href="https://twitter.com/UBIDIndia"><img src="http://13.126.160.234/ubid/app-assets/mail-assets/images/twitter.png" width="25px" alt="" srcset=""></a>
                    </div>
                </div>
                <div class="col-7 text-end">
                    <p class="mb-2">Contact Us</p>
                    <ul class="contact-details">
                        <li><a href="tel:+91 8072886122">+91 8072886122</a></li>
                        <li><a href="mailto:contact@ubidindia.com" class="contact-mail">contact@ubidindia.com</a></li>
                    </ul>
                </div>
            </div>
            <!--visit website link-->
            <a href="https://www.ubidindia.com/" class="visit-sitelink">Visit Website <span class='arrow'></span></a>
        </div>
    </div>
    <!--bootstrap js -->
    <script type="text/javascript" src="{{url('app-assets/mail-assets/js/bootstrap.min.js')}}"></script>
    <script type="text/javascript" src="{{url('app-assets/mail-assets/js/jquery-3.6.0.min.js')}}"></script>
    <script type="text/javascript" src="{{url('app-assets/mail-assets/js/popper.min.js')}}"></script>
</body>

</html>